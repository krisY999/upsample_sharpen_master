#include<stdio.h>
#include<Math.h>
#include "bmp.h"

int clip3(int v, int min, int max);

//BiCubic�����������ڼ���Ȩ��
float BiCubic(float x)
{
    float x1, a = -0.5;
    x1 = fabs(x);
    //printf("%f /", x1);
    if (x1 <= 1.0)
    {
        return (a + 2) * x1 * x1 * x1 - (a + 3) * x1 * x1 + 1;
        //return (1.0 / 2) * x1 * x1 * x1 - 1.0 * x1 * x1 + 2.0 / 3;
    }
    else if ((x1 > 1.0) & (x1 < 2.0))
    {
        return a * x1 * x1 * x1 - 5 * a * x1 * x1 + 8 * a * x1 - 4 * a;
        //return 1.0 / 6 * (2.0 - x1) * (2.0 - x1) * (2.0 - x1);
    }
    else
    {
        return 0;
    }
}

//˫���β�ֵ
//img0:ԭͼ
//img1:4kͼ(����Ҫ��ߴ��С��
BMPImage* Bicubic(BMPImage* img0, uint32_t k) {
    double W_in_0 = img0->header.width_px;
    double H_in_0 = img0->header.height_px;
    int  i, j;
    BMPImage* dst = bmp_create(W_in_0 * k, H_in_0 * k);  //����Ŀ��ͼ��
    BMPImage* img = bmp_create(W_in_0+ 4, H_in_0+ 4);  //����Ŀ��ͼ��

    for (j = 0; j < H_in_0 + 4; j++) {
        for (i = 0; i < W_in_0 + 4; i++) {
            Pixel* img1_0 = bmp_pixel_at(img, i, j);
            img1_0->r = 0;
            img1_0->g = 0;
            img1_0->b = 0;
        }
    }

    for (j = 2; j < H_in_0 + 2; j++)
    {
        for (i = 2; i < W_in_0 + 2; i++) {
            Pixel* img1_0 = bmp_pixel_at(img, i, j);
            Pixel* img0_0 = bmp_pixel_at(img0, i-2, j-2);
            img1_0->r = img0_0->r;
            img1_0->g = img0_0->g;
            img1_0->b = img0_0->b;
        }
    }

    for (j = 0; j < H_in_0*k; j++)
        for (i = 0; i < W_in_0*k; i++) {
            Pixel* out_dst1 = bmp_pixel_at(dst, i, j);

            //P�㣨x+u,y+v)
            float X = ((float)i / k) + 2.0;
            float Y = ((float)j / k) + 2.0;
            int i_x = (int)(i / k) + 2;
            int j_y = (int)(j / k) + 2;

            float i_u = X - i_x;
            float j_v = Y - j_y;

            Pixel* in1_1 = bmp_pixel_at(img, i_x - 1, j_y - 1);
            Pixel* in1_2 = bmp_pixel_at(img, i_x - 1, j_y);
            Pixel* in1_3 = bmp_pixel_at(img, i_x - 1, j_y + 1);
            Pixel* in1_4 = bmp_pixel_at(img, i_x - 1, j_y + 2);
            Pixel* in2_1 = bmp_pixel_at(img, i_x, j_y - 1);
            Pixel* in2_2 = bmp_pixel_at(img, i_x, j_y);
            Pixel* in2_3 = bmp_pixel_at(img, i_x, j_y + 1);
            Pixel* in2_4 = bmp_pixel_at(img, i_x, j_y + 2);
            Pixel* in3_1 = bmp_pixel_at(img, i_x + 1, j_y - 1);
            Pixel* in3_2 = bmp_pixel_at(img, i_x + 1, j_y);
            Pixel* in3_3 = bmp_pixel_at(img, i_x + 1, j_y + 1);
            Pixel* in3_4 = bmp_pixel_at(img, i_x + 1, j_y + 2);
            Pixel* in4_1 = bmp_pixel_at(img, i_x + 2, j_y - 1);
            Pixel* in4_2 = bmp_pixel_at(img, i_x + 2, j_y);
            Pixel* in4_3 = bmp_pixel_at(img, i_x + 2, j_y + 1);
            Pixel* in4_4 = bmp_pixel_at(img, i_x + 2, j_y + 2);

            float w_x1 = BiCubic((float)(1.0 + i_u));
            float w_x2 = BiCubic((float)(i_u));
            float w_x3 = BiCubic((float)(1.0 - i_u));
            float w_x4 = BiCubic((float)(2.0 - i_u));
            float w_y1 = BiCubic((float)(1.0 + j_v));
            float w_y2 = BiCubic((float)(j_v));
            float w_y3 = BiCubic((float)(1.0 - j_v));
            float w_y4 = BiCubic((float)(2.0 - j_v));

            float w1_r = w_x1 * w_y1 * in1_1->r + w_x1 * w_y2 * in1_2->r + w_x1 * w_y3 * in1_3->r + w_x1 * w_y4 * in1_4->r;
            float w2_r = w_x2 * w_y1 * in2_1->r + w_x2 * w_y2 * in2_2->r + w_x2 * w_y3 * in2_3->r + w_x2 * w_y4 * in2_4->r;
            float w3_r = w_x3 * w_y1 * in3_1->r + w_x3 * w_y2 * in3_2->r + w_x3 * w_y3 * in3_3->r + w_x3 * w_y4 * in3_4->r;
            float w4_r = w_x4 * w_y1 * in4_1->r + w_x4 * w_y2 * in4_2->r + w_x4 * w_y3 * in4_3->r + w_x4 * w_y4 * in4_4->r;

            float w1_g = w_x1 * w_y1 * in1_1->g + w_x1 * w_y2 * in1_2->g + w_x1 * w_y3 * in1_3->g + w_x1 * w_y4 * in1_4->g;
            float w2_g = w_x2 * w_y1 * in2_1->g + w_x2 * w_y2 * in2_2->g + w_x2 * w_y3 * in2_3->g + w_x2 * w_y4 * in2_4->g;
            float w3_g = w_x3 * w_y1 * in3_1->g + w_x3 * w_y2 * in3_2->g + w_x3 * w_y3 * in2_3->g + w_x3 * w_y4 * in3_4->g;
            float w4_g = w_x4 * w_y1 * in4_1->g + w_x4 * w_y2 * in4_2->g + w_x4 * w_y3 * in2_3->g + w_x4 * w_y4 * in4_4->g;

            float w1_b = w_x1 * w_y1 * in1_1->b + w_x1 * w_y2 * in1_2->b + w_x1 * w_y3 * in1_3->b + w_x1 * w_y4 * in1_4->b;
            float w2_b = w_x2 * w_y1 * in2_1->b + w_x2 * w_y2 * in2_2->b + w_x2 * w_y3 * in2_3->b + w_x2 * w_y4 * in2_4->b;
            float w3_b = w_x3 * w_y1 * in3_1->b + w_x3 * w_y2 * in3_2->b + w_x3 * w_y3 * in3_3->b + w_x3 * w_y4 * in3_4->b;
            float w4_b = w_x4 * w_y1 * in4_1->b + w_x4 * w_y2 * in4_2->b + w_x4 * w_y3 * in4_3->b + w_x4 * w_y4 * in4_4->b;

            //out_dst1->r = w_r;
            //out_dst1->g = w_g;
            //out_dst1->b = w_b;

            out_dst1->r = clip3((int)(w1_r + w2_r + w3_r + w4_r), 0, 255);
            out_dst1->g = clip3((int)(w1_g + w2_g + w3_g + w4_g), 0, 255);
            out_dst1->b = clip3((int)(w1_b + w2_b + w3_b + w4_b), 0, 255);

        }
    return dst;
}
