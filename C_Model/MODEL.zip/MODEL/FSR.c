#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "bmp.h"

//ȫ�ֱ���
float    FXe, FYe, FXd, FYd, FXh, FYh, FXi, FYi, Fe, Fd, Fh, Fi, We, Wd, Wh, Wi, W;
float    dx, dy, feature, Sy, Sx, lobs, clps, n_x, n_y, Feature, Feature1;
/*
        |   |                   |   |
        |   |                   |   |
--------|---|-------------------|---|-------
--------|---|-------------------|---|-------
        |   |                   |   |
        |   |                   |   |
        |   |                   |   |
        |   |                   |   |
--------|---|-------------------|---|-------
--------|---|-------------------|---|-------
        |   |                   |   |
        |   |                   |   |

*/
/*�ü�����*/
float clamp(float val, float min, float max)
{
    if (val <= min)
        val = min;
    else if (val >= max)
        val = max;
    else
        val = val;
    return val;
}

/*
//off_x�������x��ƫ��ֵ
//off_y�������y��ƫ��ֵ
//Dir_x: �����һ����x�ݶ�
//Dir_y�������һ����y�ݶ�
//Len����ʾ���ű���
//Clp����ʾw
//(x,y)����ʾ���������
//����Ȩֵ
*/
//  (25/16 * (2/5 * x^2 - 1)^2 - (25/16 - 1)) * (w * x^2 - 1)^2
//  |_______________________________________|   |_______________|
//                   base                             window
float Lanczos2(float off_x, float off_y, float Dir_x, float Dir_y, float Len_x, float Len_y, float Lob, float Clp)
{
    float L_w, dxx, dyy, x_number;

    dxx = (off_x * Dir_x) + (off_y * Dir_y);
    dyy = (off_x * -1 * Dir_y) + (off_y * Dir_x);
    dxx = dxx * Len_x;
    dyy = dyy * Len_y;
    x_number = dxx * dxx + dyy * dyy;  //��distance^2
    x_number = fmin(x_number, Clp);  //�ü�
    float WB = 0.4f * x_number - 1.0f;
    float WA = Lob * x_number - 1.0f;
    WB *= WB;
    WA *= WA;
    L_w = 1.5625f * WB + (-0.5625f);

    L_w = L_w * WA;

    return L_w;
}

/*
//(i,j):��ʾ��Χ�ĵ������
//(x,y):��ʾ����ֵ�������
//n_x: ���off_xֵ
//n_y: ���off_yֵ
*/
void distance(uint32_t x, uint32_t y, float i, float j)
{
    n_x = x - i;         //���off_xֵ
    n_y = -(j - y);
}

/*
//src: ����Ҷ�����
//(x,y): floor(P)
//(i,j): P��
//ȷ����һ�����dx,dy,feature
*/
float gradient(BMPImage* src, uint32_t x, uint32_t y, float i, float j)
{
    float Weight_e = (x + 1 - i) * (y + 1 - j);
    float Weight_d = (i - x) * (y + 1 - j);
    float Weight_h = (i - x) * (j - y);
    float Weight_i = (x + 1 - i) * (j - y);
    float DirR, Stretch;
    uint8_t Zero;

    Pixel* in1_a = bmp_pixel_at(src, x, y - 1);
    Pixel* in1_b = bmp_pixel_at(src, x + 1, y - 1);

    Pixel* in1_f = bmp_pixel_at(src, x - 1, y);
    Pixel* in1_e = bmp_pixel_at(src, x, y);
    Pixel* in1_d = bmp_pixel_at(src, x + 1, y);
    Pixel* in1_c = bmp_pixel_at(src, x + 2, y);

    Pixel* in1_j = bmp_pixel_at(src, x - 1, y + 1);
    Pixel* in1_i = bmp_pixel_at(src, x, y + 1);
    Pixel* in1_h = bmp_pixel_at(src, x + 1, y + 1);
    Pixel* in1_g = bmp_pixel_at(src, x + 2, y + 1);

    Pixel* in1_k = bmp_pixel_at(src, x, y + 2);
    Pixel* in1_n = bmp_pixel_at(src, x + 1, y + 2);

    FXe = abs(in1_f->r - in1_d->r) / fmax(abs(in1_f->r - in1_e->r), abs(in1_d->r - in1_e->r));
    FYe = abs(in1_a->r - in1_i->r) / fmax(abs(in1_a->r - in1_e->r), abs(in1_i->r - in1_e->r));
    dx += (in1_d->r - in1_f->r) ;
    dy += (in1_i->r - in1_a->r) ;
    FXe = clamp(FXe, 0.0f, 1.0f);
    FYe = clamp(FYe, 0.0f, 1.0f);
    FXe *= FXe;
    FYe *= FYe;
    Feature = 0.5 - 0.25 * ((FXe + FYe) * 0.5f) * ((FXe + FYe) * 0.5f);
    Feature1 += Feature;
    feature += Feature * Weight_e;

    FXd = abs(in1_e->r - in1_c->r) / fmax(abs(in1_e->r - in1_d->r), abs(in1_c->r - in1_d->r));
    FYd = abs(in1_b->r - in1_h->r) / fmax(abs(in1_b->r - in1_d->r), abs(in1_h->r - in1_d->r));
    dx += (in1_c->r - in1_e->r);
    dy += (in1_h->r - in1_b->r);
    FXd = clamp(FXd, 0.0f, 1.0f);
    FYd = clamp(FYd, 0.0f, 1.0f);
    FXd *= FXd;
    FYd *= FYd;
    Feature = 0.5 - 0.25 * ((FXd + FYd) * 0.5f) * ((FXd + FYd) * 0.5f);
    Feature1 += Feature;
    feature += Feature * Weight_d;

    FXh = abs(in1_i->r - in1_g->r) / fmax(abs(in1_i->r - in1_h->r), abs(in1_g->r - in1_h->r));
    FYh = abs(in1_d->r - in1_n->r) / fmax(abs(in1_d->r - in1_h->r), abs(in1_n->r - in1_h->r));
    dx += (in1_g->r - in1_i->r);
    dy += (in1_n->r - in1_d->r);
    FXh = clamp(FXh, 0.0f, 1.0f);
    FYh = clamp(FYh, 0.0f, 1.0f);
    FXh *= FXh;
    FYh *= FYh;
    Feature = 0.5 - 0.25 * ((FXh + FYh) * 0.5f) * ((FXh + FYh) * 0.5f);
    Feature1 += Feature;
    feature += Feature * Weight_h;

    FXi = abs(in1_j->r - in1_h->r) / fmax(abs(in1_j->r - in1_i->r), abs(in1_h->r - in1_i->r));
    FYi = abs(in1_e->r - in1_k->r) / fmax(abs(in1_e->r - in1_i->r), abs(in1_k->r - in1_i->r));
    dx += (in1_h->r - in1_j->r);
    dy += (in1_k->r - in1_e->r);
    FXi = clamp(FXi, 0.0f, 1.0f);
    FYi = clamp(FYi, 0.0f, 1.0f);
    FXi *= FXi;
    FYi *= FYi;
    Feature = 0.5 - 0.25 * ((FXi + FYi) * 0.5f) * ((FXi + FYi) * 0.5f);
    Feature1 += Feature;
    feature += Feature * Weight_i;

    //�ݶȹ�һ��
    DirR = dx * dx + dy * dy;
    Zero = DirR < (1.0f / 32768.0) ? 1 : 0;
    DirR = 1.0f / sqrt(DirR);
    DirR = Zero ? 1.0f : DirR;
    dx = Zero ? 1.0f : dx;
    dy = Zero ? 1.0f : dy;

    dx *= DirR;                             //cos(theta),���ֵ
    dy *= DirR;                             //sin(theta)���ֵ
    //����ռ����
/*    feature = feature * 0.5f;
    feature *= feature;  */                   //���featureֵ
    Stretch = 1.0f / fmax(abs(dx), abs(dy));
    Sx = 1.0 + (Stretch - 1.0) * Feature;   //��������ռ�
    Sy = 1.0 - 0.5 * Feature;
    lobs = feature;                         //0.5 - 0.25 * feature = lobs
    clps = 1.0f / sqrt(lobs);                      //���Lob��Clpֵ
	return 0.f;
}
/*
//�жϷŴ��ĵ��Ƿ�Ϊ��Ե��
//img: ��ֵ����
*/
int QIT(BMPImage* img, uint32_t x, uint32_t y)
{
    double W_in_0 = (img->header.width_px + 3) / 4 * 4;
    double H_in_0 = img->header.height_px;
    uint8_t i, Q;
    Pixel* out_pixel = bmp_pixel_at(img, x, y);
    i = out_pixel->r;
    if (i == 255)
        Q = 1;
    else
        Q = 0;
    return Q;
}
/*
//(x,y):��ǰ��
//(i,j):col,row
*/
int boundray(uint32_t x, uint32_t y, uint32_t i, uint32_t j)
{
    uint8_t CT;
    if ((x >= 7 && x <= i - 8) && (y >= 7 && y <= j - 8))
        CT = 1;
    else
        CT = 0;
    return CT;
}
/*
//img0:1Kԭͼ
//img1:4Kԭͼ
//img3:4K��ֵ��ͼ
//img2:1K �Ҷ�ͼ
//dst:���ͼ
*/
BMPImage* FSR(BMPImage* img0, BMPImage* img1, BMPImage* img3, BMPImage* img2)      //FSR
{
    double W_in_0 = (img1->header.width_px + 3) / 4 * 4;
    double H_in_0 = img1->header.height_px;
    uint32_t  i, j;
    BMPImage* dst = bmp_create(W_in_0, H_in_0);  //����Ŀ��ͼ��

    for (j = 0; j < H_in_0; j++)
        for (i = 0; i < W_in_0; i++)
        {
            uint8_t  WT = boundray(i, j, W_in_0, H_in_0);
            if (WT == 1)
            {
                uint8_t QT = QIT(img3, i, j);
                //��ʾΪƽ̹��
                if (QT == 0)
                {
                    Pixel* out_dst = bmp_pixel_at(dst, i, j);
                    Pixel* out_img1 = bmp_pixel_at(img1, i, j);

                    out_dst->r = out_img1->r;
                    out_dst->g = out_img1->g;
                    out_dst->b = out_img1->b;
                }
                //��ʾ��Ե��
                else
                {
                    Pixel* out_dst1 = bmp_pixel_at(dst, i, j);

                    double   F_W = i * 0.25f + 0.5f * (0.25f - 1.0f);  //��������������(y,x)
                    double   F_H = j * 0.25f + 0.5f * (0.25f - 1.0f);

                    uint32_t x = floor(F_W);  //������������ȡ��
                    uint32_t y = floor(F_H);

                    float La, Lb, Lf, Le, Ld, Lc, Lj, Li, Lh, Lg, Lk, Ln, L_sum;
                    dx = 0; dy = 0; feature = 0;

                    gradient(img2, x, y, F_W, F_H);   //һ��

                    distance(x, y - 1, F_W, F_H);   //��12��
                    La = Lanczos2(n_x, n_y, dx, dy, Sx, Sy, lobs, clps);

                    distance(x + 1, y - 1, F_W, F_H);
                    Lb = Lanczos2(n_x, n_y, dx, dy, Sx, Sy, lobs, clps);

                    distance(x - 1, y, F_W, F_H);
                    Lf = Lanczos2(n_x, n_y, dx, dy, Sx, Sy, lobs, clps);

                    distance(x, y, F_W, F_H);
                    Le = Lanczos2(n_x, n_y, dx, dy, Sx, Sy, lobs, clps);

                    distance(x + 1, y, F_W, F_H);
                    Ld = Lanczos2(n_x, n_y, dx, dy, Sx, Sy, lobs, clps);

                    distance(x + 2, y, F_W, F_H);
                    Lc = Lanczos2(n_x, n_y, dx, dy, Sx, Sy, lobs, clps);

                    distance(x - 1, y + 1, F_W, F_H);
                    Lj = Lanczos2(n_x, n_y, dx, dy, Sx, Sy, lobs, clps);

                    distance(x, y + 1, F_W, F_H);
                    Li = Lanczos2(n_x, n_y, dx, dy, Sx, Sy, lobs, clps);

                    distance(x + 1, y + 1, F_W, F_H);
                    Lh = Lanczos2(n_x, n_y, dx, dy, Sx, Sy, lobs, clps);

                    distance(x + 2, y + 1, F_W, F_H);
                    Lg = Lanczos2(n_x, n_y, dx, dy, Sx, Sy, lobs, clps);

                    distance(x, y + 2, F_W, F_H);
                    Lk = Lanczos2(n_x, n_y, dx, dy, Sx, Sy, lobs, clps);

                    distance(x + 1, y + 2, F_W, F_H);
                    Ln = Lanczos2(n_x, n_y, dx, dy, Sx, Sy, lobs, clps);

                    L_sum = La + Lb + Lf + Le + Ld + Lc + Lj + Li + Lh + Lg + Lk + Ln;

                    Pixel* in2_a = bmp_pixel_at(img0, x, y - 1);
                    Pixel* in2_b = bmp_pixel_at(img0, x + 1, y - 1);
                    Pixel* in2_f = bmp_pixel_at(img0, x - 1, y);
                    Pixel* in2_e = bmp_pixel_at(img0, x, y);
                    Pixel* in2_d = bmp_pixel_at(img0, x + 1, y);
                    Pixel* in2_c = bmp_pixel_at(img0, x + 2, y);
                    Pixel* in2_j = bmp_pixel_at(img0, x - 1, y + 1);
                    Pixel* in2_i = bmp_pixel_at(img0, x, y + 1);
                    Pixel* in2_h = bmp_pixel_at(img0, x + 1, y + 1);
                    Pixel* in2_g = bmp_pixel_at(img0, x + 2, y + 1);
                    Pixel* in2_k = bmp_pixel_at(img0, x, y + 2);
                    Pixel* in2_n = bmp_pixel_at(img0, x + 1, y + 2);

                    uint8_t A_r = fmax(in2_e->r, fmax(in2_d->r, fmax(in2_h->r, in2_i->r)));
                    uint8_t A_g = fmax(in2_e->g, fmax(in2_d->g, fmax(in2_h->g, in2_i->g)));
                    uint8_t A_b = fmax(in2_e->g, fmax(in2_d->g, fmax(in2_h->g, in2_i->g)));
                    uint8_t B_r = fmin(in2_e->r, fmin(in2_d->r, fmin(in2_h->r, in2_i->r)));
                    uint8_t B_g = fmin(in2_e->g, fmin(in2_d->g, fmin(in2_h->g, in2_i->g)));
                    uint8_t B_b = fmin(in2_e->g, fmin(in2_d->g, fmin(in2_h->g, in2_i->g)));

                    uint8_t rr = (in2_a->r * La + in2_b->r * Lb + in2_f->r * Lf + in2_e->r * Le + in2_d->r * Ld + in2_c->r * Lc +
                        in2_j->r * Lj + in2_i->r * Li + in2_h->r * Lh + in2_g->r * Lg + in2_k->r * Lk + in2_n->r * Ln) / L_sum;

                    uint8_t gg = (in2_a->g * La + in2_b->g * Lb + in2_f->g * Lf + in2_e->g * Le + in2_d->g * Ld + in2_c->g * Lc +
                        in2_j->g * Lj + in2_i->g * Li + in2_h->g * Lh + in2_g->g * Lg + in2_k->g * Lk + in2_n->g * Ln) / L_sum;

                    uint8_t bb = (in2_a->b * La + in2_b->b * Lb + in2_f->b * Lf + in2_e->b * Le + in2_d->b * Ld + in2_c->b * Lc +
                        in2_j->b * Lj + in2_i->b * Li + in2_h->b * Lh + in2_g->b * Lg + in2_k->b * Lk + in2_n->b * Ln) / L_sum;


                    out_dst1->r = rr;
                    out_dst1->g = gg;
                    out_dst1->b = bb;
                    out_dst1->r = fmin(A_r, fmax(B_r, rr));
                    out_dst1->g = fmin(A_g, fmax(B_g, gg));
                    out_dst1->b = fmin(A_b, fmax(B_b, bb));

                    //////��
                    //Pixel* out_dst0 = bmp_pixel_at(dst, i, j);
                    //out_dst0 = out_dst1;

                    //Pixel* in0_1 = bmp_pixel_at(out_dst1, x + 1, y);
                    //Pixel* in0_2 = bmp_pixel_at(out_dst1, x, y + 1);
                    //Pixel* in0_3 = bmp_pixel_at(out_dst1, x + 1, y);
                    //Pixel* in0_4 = bmp_pixel_at(out_dst1, x, y + 1);
                    //Pixel* in0_0 = bmp_pixel_at(out_dst1, x, y);

                    ////A_r = fmax(in0_0->r, fmax(in0_1->r, fmax(in0_2->r, fmax(in0_3->r, in0_4->r))));
                    //A_r = max(in0_0., in0_1);
                    //A_g = fmax(in0_0->g, fmax(in0_1->g, fmax(in0_2->g, fmax(in0_3->g, in0_4->g))));
                    //A_b = fmax(in0_0->b, fmax(in0_1->g, fmax(in0_2->g, fmax(in0_3->g, in0_4->g))));
                    //B_r = fmin(in0_0->r, fmin(in0_1->r, fmin(in0_2->r, fmin(in0_3->r, in0_4->r))));
                    //B_g = fmin(in0_0->g, fmin(in0_1->g, fmin(in0_2->g, fmin(in0_3->g, in0_4->g))));
                    //B_b = fmin(in0_0->b, fmin(in0_1->g, fmin(in0_2->g, fmin(in0_3->g, in0_4->g))));

                    //float w_r = (fmax(-B_r / (4 * A_r), (1 - A_r) / ((4 * B_r - 4)))) * 0.25;
                    //float w_g = (fmax(-B_g / (4 * A_g), (1 - A_g) / ((4 * B_g - 4)))) * 0.25;
                    //float w_b = (fmax(-B_b / (4 * A_b), (1 - A_b) / ((4 * B_b - 4)))) * 0.25;

                    //out_dst0->r = (w_r * (in0_1->r + in0_2->r + in0_3->r + in0_4->r) + in0_0->r) / (4 * w_r + 1);
                    //out_dst0->g = (w_g * (in0_1->g + in0_2->g + in0_3->g + in0_4->g) + in0_0->g) / (4 * w_g + 1);
                    //out_dst0->r = (w_b * (in0_1->b + in0_2->b + in0_3->b + in0_4->b) + in0_0->b) / (4 * w_b + 1);

                    //out_dst0->r = fmax(out_dst0->r, rr);
                    //out_dst0->g = fmax(out_dst0->g, gg);
                    //out_dst0->b = fmax(out_dst0->b, bb);
                }


            }
            else
            {
                Pixel* out1_dst = bmp_pixel_at(dst, i, j);
                Pixel* out1_img1 = bmp_pixel_at(img1, i, j);

                out1_dst->r = out1_img1->r;
                out1_dst->g = out1_img1->g;
                out1_dst->b = out1_img1->b;
            }
        }
    return dst;
}