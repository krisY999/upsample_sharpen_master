#include <stdio.h>
#include <math.h>
#include "bmp.h"
/*
//�ߴ��Զ���
//img:����RBGͼ��
//dst:�Ҷ�ͼƬ
*/
BMPImage* bmp_gray(BMPImage* img)
{

	uint32_t w_i = (img->header.width_px + 3) / 4 * 4;
	uint32_t h_i = img->header.height_px;

	BMPImage* dst = bmp_create(w_i, h_i);

	uint32_t gray; // color channels
	uint32_t x, y;
	for (y = 0; y < h_i; y++) {
		for (x = 0; x < w_i; x++) {
			Pixel* p = bmp_pixel_at(img, x, y);
			gray = (p->r * 114 + p->g * 587 + p->b * 299) / 1000;

			Pixel* t = bmp_pixel_at(dst, x, y);
			t->r = (uint8_t)gray;
			t->g = (uint8_t)gray;
			t->b = (uint8_t)gray;
		}
	}
	return dst;
}