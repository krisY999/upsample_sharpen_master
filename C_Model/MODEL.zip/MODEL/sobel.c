#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <string.h>
#include "bmp.h"
#include "guass.h"

#define   SOBEL_THRESHOLD    100  //��ֵ�����Ż�
#define   ROW             2160
#define   COL             3840
uint32_t 		image_data[COL + 2][ROW + 2];
uint32_t 		Gxy[COL][ROW];
uint32_t 		Gx[COL][ROW];
uint32_t 		Gy[COL][ROW];
uint32_t        THRESHOLD[COL][ROW];

void store(BMPImage* img, BMPImage* rst)
{
	uint8_t MAX_ = 254;
	uint8_t MIN_ = 1;
	int i;
	uint32_t w_i = (img->header.width_px + 3) / 4 * 4;
	uint32_t h_i = img->header.height_px;

	uint32_t x, y;
	for (y = 1; y < h_i + 1; y++) {
		for (x = 1; x < w_i + 1; x++) {
			Pixel* p = bmp_pixel_at(rst, x - 1, y - 1);
			if (p->r >= MAX_)
				image_data[x][y] = 255;
			else if (p->r <= MIN_)
				image_data[x][y] = 0;
			else
				image_data[x][y] = p->r;

		}
	}
}
//���ͼ�������������Ϊ��
void padding(BMPImage* img) {
	int i;
	for (i = 0; i < img->header.width_px; i++) {
		image_data[i][0] = 0;
		image_data[i][img->header.height_px + 1] = 0;
	}
	for (i = 0; i < img->header.height_px; i++) {
		image_data[0][i] = 0;
		image_data[img->header.width_px + 1][i] = 0;
	}
}
//����3*3��
//��������(row,col)
int convolution(int kernel[3][3], int row, int col) {
	int i, j, sum = 0;
	for (i = -1; i < 2; i++) {
		for (j = -1; j < 2; j++) {
			sum += image_data[j + col][i + row] * kernel[i + 1][j + 1];
		}
	}
	return sum;
}
//sobel ���ӱ��ؼ��
void sobel_edge_detector(BMPImage* img) {
	uint32_t i, j, gx, gy;

	int mx[3][3] = {
		{-1, 0, 1},
		{-2, 0, 2},
		{-1, 0, 1}
	};
	int my[3][3] = {
		{-1, -2, -1},
		{0, 0, 0},
		{1, 2, 1}
	};

	uint32_t w_i = (img->header.width_px + 3) / 4 * 4;
	uint32_t h_i = img->header.height_px;

	for (i = 1; i < img->header.height_px + 1; i++) {
		for (j = 1; j < img->header.width_px + 1; j++) {
			gx = convolution(mx, i, j);
			gy = convolution(my, i, j);
			Gxy[j - 1][i - 1] = (uint8_t)sqrt(gx * gx + gy * gy);
			Gx[j - 1][i - 1] = (uint8_t)gx;
			Gy[j - 1][i - 1] = (uint8_t)gy;
		}
	}
}
//��׼��
void min_max_normalization(BMPImage* img) {
	int min = 1000000, max = 0, i, j;
	uint32_t w_i = (img->header.width_px + 3) / 4 * 4;
	uint32_t h_i = img->header.height_px;
	for (i = 0; i < h_i; i++) {
		for (j = 0; j < w_i; j++) {
			if (Gxy[j][i] < min) {
				min = Gxy[j][i];
			}
			else if (Gxy[j][i] > max) {
				max = Gxy[j][i];
			}
			else {
				min = min;
				max = max;
			}
		}
	}
	for (i = 0; i < h_i; i++) {
		for (j = 0; j < w_i; j++) {
			double ratio = (double)(Gxy[j][i] - min) / (max - min);
			Gxy[j][i] = ratio * 255;
		}
	}
}
//��ֵ��
void Image_Binarization(BMPImage* img) {
	int i, j;
	uint32_t w_i = (img->header.width_px + 3) / 4 * 4;
	uint32_t h_i = img->header.height_px;
	for (i = 0; i < h_i; i++) {
		for (j = 0; j < w_i; j++) {
			if (Gxy[j][i] > SOBEL_THRESHOLD)
				THRESHOLD[j][i] = 255;
			else
				THRESHOLD[j][i] = 0;

		}
	}
}
/*
//img��ԭͼ��
//dst: �Ҷ�ͼ��
//dst1����ֵ��ͼ��
*/
BMPImage* bmp_sobel(BMPImage* img, BMPImage* dst)
{
	uint32_t  w = (img->header.width_px + 3) / 4 * 4;
	uint32_t  h = img->header.height_px;

	// 	BMPImage *dst0 = bmp_create(w, h);   //����dstͼƬ
	//	BMPImage *dst = bmp_gray(img); //ת�Ҷ�
	//	BMPImage *rst = GaussianFilter(img,dst);
	store(img, dst);   //�洢����
	padding(img);    //�������
	sobel_edge_detector(img);  //��Ե���
	min_max_normalization(img);  //��׼��
	Image_Binarization(img);  //��ֵ��

	BMPImage* dst1 = bmp_create(w, h);   //������ɫ��Ե������ͼƬ
	int i, j;
	for (i = 0; i < h; i++) {
		for (j = 0; j < w; j++) {
			Pixel* s = bmp_pixel_at(dst1, j, i);
			s->r = (uint8_t)THRESHOLD[j][i];
			s->g = (uint8_t)THRESHOLD[j][i];
			s->b = (uint8_t)THRESHOLD[j][i];
		}
	}
	return dst1;
}