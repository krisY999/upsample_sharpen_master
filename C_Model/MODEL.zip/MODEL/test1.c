#include <stdio.h>
#include <stdlib.h>
#include "bmp.h"

#define   ROW             2160
#define   COL             3840
uint32_t        THRESHOLD[COL][ROW];

//int boundray(uint32_t x, uint32_t y, uint32_t i, uint32_t j);
//BMPImage* bmp_gray(BMPImage* img);
//BMPImage* bmp_sobel(BMPImage* img, BMPImage* dst);

int clip3(int v, int min, int max) {
    int ret = v;
    if (ret < min) {
        ret = min;
    }
    else if (ret > max) {
        ret = max;
    }
    return ret;
}

BMPImage* Test(BMPImage* img1, BMPImage* img4, BMPImage* img2) {
    //img0 = bmp_gray(img1);
    double W_in_0 = img1->header.width_px;
    double H_in_0 = img1->header.height_px;
    uint32_t  i, j;
    BMPImage* dst = bmp_create(W_in_0, H_in_0);  //����Ŀ��ͼ��
    uint32_t gaussianMmat[3][3] = { {1,2,1},{2,4,2},{1,2,1} };//��˹ģ��

    for (j = 1; j < H_in_0 - 1; j++)
    {
        for (i = 1; i < W_in_0 - 1; i++)
        {
            //uint8_t  WT = boundray(i, j, W_in_0, H_in_0);
            Pixel* img_sobel = bmp_pixel_at(img2, i, j);
            if (img_sobel->r == 255)
            {
                Pixel* out_dst1 = bmp_pixel_at(dst, i, j);
                Pixel* out1_img1 = bmp_pixel_at(img1, i, j);

                ////��

                Pixel* in0_1 = bmp_pixel_at(img4, i - 1, j - 1);
                Pixel* in0_2 = bmp_pixel_at(img4, i - 1, j);
                Pixel* in0_3 = bmp_pixel_at(img4, i - 1, j + 1);
                Pixel* in0_4 = bmp_pixel_at(img4, i, j - 1);
                Pixel* in0_5 = bmp_pixel_at(img4, i, j);
                Pixel* in0_6 = bmp_pixel_at(img4, i, j + 1);
                Pixel* in0_7 = bmp_pixel_at(img4, i + 1, j - 1);
                Pixel* in0_8 = bmp_pixel_at(img4, i + 1, j);
                Pixel* in0_9 = bmp_pixel_at(img4, i + 1, j + 1);

                Pixel* in = bmp_pixel_at(img1, i, j);

                float w_1_r = in0_1->r * gaussianMmat[0][0];
                float w_2_r = in0_2->r * gaussianMmat[0][1];
                float w_3_r = in0_3->r * gaussianMmat[0][2];
                float w_4_r = in0_4->r * gaussianMmat[1][0];
                float w_5_r = in0_5->r * gaussianMmat[1][1];
                float w_6_r = in0_6->r * gaussianMmat[1][2];
                float w_7_r = in0_7->r * gaussianMmat[2][0];
                float w_8_r = in0_8->r * gaussianMmat[2][1];
                float w_9_r = in0_9->r * gaussianMmat[2][2];
                 
                float w_r = (w_1_r + w_2_r + w_3_r + w_4_r + w_5_r + w_6_r + w_7_r + w_8_r + w_9_r) / 16.0;
                float w_low_r = clip3(in->r - w_r, 0, 255);//ϸ��ͼ��
                if (w_low_r > 2) {
                    float w_detail_r = (w_low_r * 20.0) / 16.0;//ϸ�ڼ�Ȩ��
                    out_dst1->r = clip3((int)(in->r + w_detail_r), 0, 255);
                }
                else {
                    out_dst1->r = out1_img1->r;
                }

                float w_g = (w_1_r + w_2_r + w_3_r + w_4_r + w_5_r + w_6_r + w_7_r + w_8_r + w_9_r) / 16.0;
                float w_low_g = clip3(in->g - w_g, 0, 255);
                if (w_low_g > 2) {
                    float w_detail_g = (w_low_g * 20.0) / 16.0;
                    out_dst1->g = clip3((int)(in->g + w_detail_g), 0, 255);
                }
                else {
                    out_dst1->g = out1_img1->g; 
                }

                float w_b = (w_1_r + w_2_r + w_3_r + w_4_r + w_5_r + w_6_r + w_7_r + w_8_r + w_9_r) / 16.0;
                float w_low_b = clip3(in->b - w_b, 0, 255);
                if (w_low_b > 2) {
                    float w_detail_b = (w_low_b * 20.0) / 16.0;
                    out_dst1->b = clip3((int)(in->b + w_detail_b), 0, 255);
                }
                else {
                    out_dst1->b = out1_img1->b;
                }
            }
            else {
                Pixel* out_dst1 = bmp_pixel_at(dst, i, j);
                Pixel* out1_img1 = bmp_pixel_at(img1, i, j);
                out_dst1->r = out1_img1->r;
                out_dst1->g = out1_img1->g;
                out_dst1->b = out1_img1->b;
            }
        }
     }
    return dst;

}