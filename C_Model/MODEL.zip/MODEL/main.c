#define _CRT_SECURE_NO_WARNINGS 1

#include "bmp.h"

//��������    
BMPImage* bmp_gray(BMPImage* img);
BMPImage* bmp_sobel(BMPImage* img, BMPImage* dst);
BMPImage* Test(BMPImage* img1, BMPImage* img4, BMPImage* img2);
BMPImage* Bicubic(BMPImage* img0, uint32_t k);

int main(int argc, char ** argv)
{
	/*
	//img0:1Kԭͼ
	//img2:˫���Ķ�ֵ��ͼ��
	//img4��˫����4K�Ҷ�ͼ
	//img_bic: ˫���β�ֵͼ
	//output1:��ͼ��
	*/
	BMPImage* img0 = NULL, * img2 = NULL, * img4 = NULL, * output1 = NULL;
	BMPImage* img_bic = NULL;
	do {

		//��ȡimg0:1Kԭͼ
		img0 = bmp_read("E:/project/FPGA_contest_pro/���������ݼ�/downscaled/0.bmp");
		if (img0 == NULL)
		{
			printf("read 1k.bmp failed\n");
			break;
		}

		//img_bic: ˫���β�ֵͼ
		img_bic = Bicubic(img0, 4);
		if (img_bic == NULL)
		{
			printf("bicubic failed\n");
			break;
		}
		bmp_write(img_bic, "0_bic.bmp");

		//img4��˫����4K�Ҷ�ͼ
		img4 = bmp_gray(img_bic);
		if (img4 == NULL)
		{
			printf("bmp gray img1(4K) failed\n");
			break;
		}
		//img2:˫���Ķ�ֵ��ͼ��
		img2 = bmp_sobel(img_bic, img4);
		bmp_write(img2, "sobel_4k.bmp");

		//output1:��ͼ��
		output1 = Test(img_bic, img4, img2);
		bmp_write(output1, "0.bmp");
		
	} while (0);
	

	//headers
	printf("*********************************************\n");
	printf("*********************************************\n");
	printf("*******************1k header*****************\n");
	bmp_print_header(img0);
	printf("*******************4k sobeled header**********\n");
	bmp_print_header(img2);
	printf("**************  4k grayed header   *********\n");
	bmp_print_header(img4);
	printf("**************       output1 4k     *********\n");
	bmp_print_header(output1);
	//printf("*********************************************\n");
	//printf("*********************************************\n");


	//to free pointers
	bmp_free(img0);
	bmp_free(img2);
	//bmp_free(img3);
	bmp_free(img4);
	bmp_free(img_bic);
	//bmp_free(output);
	bmp_free(output1);

	return 0;
}