
#include <iostream>
#include <opencv2/opencv.hpp>

using namespace std;
using namespace cv;
float a = -0.5; //bicubic������
void get_w(float w_x[4], float x)
{
	int X = (int)x;
	float tmp[4];
	tmp[0] = 1 + (x - X);
	tmp[1] = (x - X);
	tmp[2] = 1 - (x - X);
	tmp[3] = 2 - (x - X);
	
	w_x[0] = a * abs(tmp[0] * tmp[0] * tmp[0]) - 5 * a * tmp[0] * tmp[0] + 8 * a * abs(tmp[0]) - 4 * a;			//�������Ϊ2�ĵ�
	w_x[1] = (a + 2) * abs(tmp[1] * tmp[1] * tmp[1]) - (a + 3) * tmp[1] * tmp[1] + 1;							//�������Ϊ1�ĵ�
	w_x[2] = (a + 2) * abs(tmp[2] * tmp[2] * tmp[2]) - (a + 3) * tmp[2] * tmp[2] + 1;							//�������Ϊ1�ĵ�
	w_x[3] = a * abs(tmp[3] * tmp[3] * tmp[3]) - 5 * a * tmp[3] * tmp[3] + 8 * a * abs(tmp[3]) - 4 * a;			//�������Ϊ2�ĵ�

}

void bicubic(void* src, void* dst)
{

	float** biggerImage = (float**)dst;//�Ŵ�������ͼ��
								
	float** src_img = (float**)src;


	//�������2��2��
	float** src_inc = new float* [544];
	for (int i = 0; i < 544; i++)
	{
		src_inc[i] = new float[964];
	}

	src_inc[0][0] = src_img[0][0];
	src_inc[0][1] = src_img[0][0];
	src_inc[1][0] = src_img[0][0];
	src_inc[1][1] = src_img[0][0];
	src_inc[0][962] = src_img[0][959];
	src_inc[0][963] = src_img[0][959];
	src_inc[1][962] = src_img[0][959];
	src_inc[1][963] = src_img[0][959];

	src_inc[542][0] = src_img[539][0];
	src_inc[542][1] = src_img[539][0];
	src_inc[543][0] = src_img[539][0];
	src_inc[543][1] = src_img[539][0];
	src_inc[542][962] = src_img[539][959];
	src_inc[542][963] = src_img[539][959];
	src_inc[543][962] = src_img[539][959];
	src_inc[543][963] = src_img[539][959];

	for (int i = 2; i < 962; i++)
	{
		src_inc[0][i] = src_img[0][i - 2];
		src_inc[1][i] = src_img[0][i - 2];
		src_inc[542][i] = src_img[539][i - 2];
		src_inc[543][i] = src_img[539][i - 2];
	}
	for (int i = 2; i < 542; i++)
	{
		src_inc[i][0] = src_img[i - 2][0];
		src_inc[i][1] = src_img[i - 2][0];
		src_inc[i][962] = src_img[i - 2][959];
		src_inc[i][963] = src_img[i - 2][959];
	}
	//�������ͼƬ
	for (int i = 2; i < 542; i++)
	{
		for (int j = 2; j < 962; j++)
		{
			src_inc[i][j] = src_img[i - 2][j - 2];
		}
	}

	//������


	for (int i = 0; i < 1080; i++)
	{
		for (int j = 0; j < 1920; j++)
		{
			//�Ŵ��ͼ��λ�������Դͼ���λ��
			//�Ż����ƫ�Ƶ�
			float x = (i + 0.5) * 0.5 + 2 - 0.5;
			float y = (j + 0.5) * 0.5 + 2 - 0.5;
			//�Ż�ǰ��ƫ�Ƶ�
			//float x = i * 0.5 + 2;
			//float y = j * 0.5 + 2;

			float w_x[4], w_y[4];//���з����Ȩϵ��

			get_w(w_x, x);//����16����Ȩֵ
			get_w(w_y, y);
			float temp = 0;

			//������Ȩ
			for (int s = 0; s < 4; s++)
			{
				for (int t = 0; t < 4; t++)
				{
					temp += src_inc[int(x) + s - 1][int(y) + t - 1] * w_x[s] * w_y[t];
				}
			}

			biggerImage[i][j] = (uchar)temp;
			//cout << biggerImage[i][j] << " ";
		}
		//cout << endl;
	}

}

//�ڶ��ηŴ�������ټ���
void bicubic_1(void* src, void* dst)
{

	float** biggerImage = (float**)dst;//�Ŵ�������ͼ��

	float** src_img = (float**)src;


	//�������2��2��
	float** src_inc = new float* [1084];
	for (int i = 0; i < 1084; i++)
	{
		src_inc[i] = new float[1924];
	}

	src_inc[0][0] = src_img[0][0];
	src_inc[0][1] = src_img[0][0];
	src_inc[1][0] = src_img[0][0];
	src_inc[1][1] = src_img[0][0];
	src_inc[0][1922] = src_img[0][1919];
	src_inc[0][1923] = src_img[0][1919];
	src_inc[1][1922] = src_img[0][1919];
	src_inc[1][1923] = src_img[0][1919];

	src_inc[1082][0] = src_img[1079][0];
	src_inc[1082][1] = src_img[1079][0];
	src_inc[1083][0] = src_img[1079][0];
	src_inc[1083][1] = src_img[1079][0];
	src_inc[1082][1922] = src_img[1079][1919];
	src_inc[1082][1923] = src_img[1079][1919];
	src_inc[1083][1922] = src_img[1079][1919];
	src_inc[1083][1923] = src_img[1079][1919];

	for (int i = 2; i < 1922; i++)
	{
		src_inc[0][i] = src_img[0][i - 2];
		src_inc[1][i] = src_img[0][i - 2];
		src_inc[1082][i] = src_img[1079][i - 2];
		src_inc[1083][i] = src_img[1079][i - 2];
	}
	for (int i = 2; i < 1082; i++)
	{
		src_inc[i][0] = src_img[i - 2][0];
		src_inc[i][1] = src_img[i - 2][0];
		src_inc[i][1922] = src_img[i - 2][1919];
		src_inc[i][1923] = src_img[i - 2][1919];
	}
	//�������ͼƬ
	for (int i = 2; i < 1082; i++)
	{
		for (int j = 2; j < 1922; j++)
		{
			src_inc[i][j] = src_img[i - 2][j - 2];
		}
	}

	//������


	for (int i = 0; i < 2160; i++)
	{
		for (int j = 0; j < 3840; j++)
		{
			//�Ŵ��ͼ��λ�������Դͼ���λ��
			//�Ż����ƫ�Ƶ�
			float x = (i + 0.5) * 0.5 + 2 - 0.5;
			float y = (j + 0.5) * 0.5 + 2 - 0.5;
			//�Ż�ǰ��ƫ�Ƶ�
			//float x = i * 0.5 + 2;
			//float y = j * 0.5 + 2;

			float w_x[4], w_y[4];//���з����Ȩϵ��

			get_w(w_x, x);//����16����Ȩֵ
			get_w(w_y, y);
			float temp = 0;

			//������Ȩ
			for (int s = 0; s < 4; s++)
			{
				for (int t = 0; t < 4; t++)
				{
					temp += src_inc[int(x) + s - 1][int(y) + t - 1] * w_x[s] * w_y[t];
				}
			}

			biggerImage[i][j] = (uchar)temp;
			//cout << biggerImage[i][j] << " ";
		}
		//cout << endl;
	}

}



int main()
{
	Mat ini = imread("E:\\project\\FPGA_contest_pro\\C_Model\\bicubic_my\\1k.bmp", 0);
	imshow("initial_pic", ini);
	float** src = new float* [540];
	float** dst = new float* [1080];
	
	for (int i = 0; i < 540; i++)
	{
		src[i] = new float[960];

		for (int j = 0; j < 960; j++)
		{
			src[i][j] = ini.at<uchar>(i, j);
		}
	}

	for (int i = 0; i < 1080; i++)
	{
		dst[i] = new float[1920];
	}

	bicubic((void*)src, (void*)dst);

	Mat out(1080, 1920, CV_8UC1);
	for (int i = 0; i < 1080; i++)
	{
		for (int j = 0; j < 1920; j++)
		{
			out.at<uchar>(i, j) = dst[i][j];
		}
	}

//�ڶ���2���Ŵ�1080p -> 4k
	float** src_1 = new float* [1080];
	float** dst_1 = new float* [2160];

	for (int i = 0; i < 1080; i++)
	{
		src_1[i] = new float[1920];

		for (int j = 0; j < 1920; j++)
		{
			src_1[i][j] = out.at<uchar>(i, j);
		}
	}

	for (int i = 0; i < 2160; i++)
	{
		dst_1[i] = new float[3840];
	}

	bicubic_1((void*)src_1, (void*)dst_1);

	Mat out_1(2160, 3840, CV_8UC1);
	for (int i = 0; i < 2160; i++)
	{
		for (int j = 0; j < 3840; j++)
		{
			out_1.at<uchar>(i, j) = dst_1[i][j];
		}
	}
	

	imshow("resize_pic_1080p", out);
	cv::imwrite("resize_pic_1080p.bmp", out);
	
	imshow("resize_pic_4k", out_1);
	cv::imwrite("resize_pic_4k.bmp", out_1);
	
	
	printf("hello world!");

	waitKey(0);


	return 0;
}
