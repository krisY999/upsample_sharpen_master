#include <stdio.h>
#include <stdlib.h>
#include "bmp.h"

int boundray(uint32_t x, uint32_t y, uint32_t i, uint32_t j);
BMPImage* bmp_gray(BMPImage* img);
int QIT(BMPImage* img, uint32_t x, uint32_t y);

BMPImage* Sharpen(BMPImage* img1) {
    BMPImage* img0 = NULL;
    img0 = bmp_gray(img1);
    double W_in_0 = (img1->header.width_px + 3) / 4 * 4;
    double H_in_0 = img1->header.height_px;
    uint32_t  i, j;
    BMPImage* dst = bmp_create(W_in_0, H_in_0);  //����Ŀ��ͼ��

    for (j = 0; j < H_in_0; j++)
        for (i = 0; i < W_in_0; i++)
        {
            uint8_t  WT = boundray(i, j, W_in_0, H_in_0);
            if (WT == 1)
            {
                Pixel* out_dst1 = bmp_pixel_at(dst, i, j);
                Pixel* out1_img1 = bmp_pixel_at(img1, i, j);

                ////��

                Pixel* in1_1 = bmp_pixel_at(img1, i - 1, j);
                Pixel* in1_2 = bmp_pixel_at(img1, i, j - 1);
                Pixel* in1_3 = bmp_pixel_at(img1, i + 1, j);
                Pixel* in1_4 = bmp_pixel_at(img1, i, j + 1);
                Pixel* in1_0 = bmp_pixel_at(img1, i, j);

                Pixel* in0_1 = bmp_pixel_at(img0, i - 1, j);
                Pixel* in0_2 = bmp_pixel_at(img0, i, j - 1);
                Pixel* in0_3 = bmp_pixel_at(img0, i + 1, j);
                Pixel* in0_4 = bmp_pixel_at(img0, i, j + 1);
                Pixel* in0_0 = bmp_pixel_at(img0, i, j);

                float A_r = fmax(in0_0->r, fmax(in0_1->r, fmax(in0_2->r, fmax(in0_3->r, in0_4->r))));
                //float A_g = fmax(in0_0->g, fmax(in0_1->g, fmax(in0_2->g, fmax(in0_3->g, in0_4->g))));
                //float A_b = fmax(in0_0->b, fmax(in0_1->g, fmax(in0_2->g, fmax(in0_3->g, in0_4->g))));
                float B_r = fmin(in0_0->r, fmin(in0_1->r, fmin(in0_2->r, fmin(in0_3->r, in0_4->r))));
                //float B_g = fmin(in0_0->g, fmin(in0_1->g, fmin(in0_2->g, fmin(in0_3->g, in0_4->g))));
                //float B_b = fmin(in0_0->b, fmin(in0_1->g, fmin(in0_2->g, fmin(in0_3->g, in0_4->g))));

                uint8_t w_r = (fmax(-B_r / (4 * A_r), (1 - A_r) / (4 * B_r - 4))) * 4;
                //uint8_t w_g = (fmax(-B_g / (4 * A_g), (1 - A_g) / (4 * B_g - 4))) * 4;
                //uint8_t w_b = (fmax(-B_b / (4 * A_b), (1 - A_b) / (4 * B_b - 4))) * 4;

                out_dst1->r = (w_r * (in1_1->r + in1_2->r + in1_3->r + in1_4->r) + in1_0->r) / (4 * w_r + 1);
                out_dst1->g = (w_r * (in1_1->g + in1_2->g + in1_3->g + in1_4->g) + in1_0->g) / (4 * w_r + 1);
                out_dst1->b = (w_r * (in1_1->b + in1_2->b + in1_3->b + in1_4->b) + in1_0->b) / (4 * w_r + 1);
                //out_dst1->r = out1_img1->r;
                //out_dst1->g = out1_img1->g;
                //out_dst1->b = out1_img1->b;
            }
            else {
                Pixel* out_dst1 = bmp_pixel_at(dst, i, j);
                Pixel* out1_img1 = bmp_pixel_at(img1, i, j);
                out_dst1->r = out1_img1->r;
                out_dst1->g = out1_img1->g;
                out_dst1->b = out1_img1->b;
            }
        }
    return dst;

}