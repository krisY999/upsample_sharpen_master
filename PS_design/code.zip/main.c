
#include <stdio.h>
#include "xparameters.h"
#include "xsdps.h"
#include "xil_printf.h"
#include "ff.h"
#include "bmp.h"
#include "sleep.h"
#include "xhls_video_scaler_top.h"
#include "wr_bmp/wr_bmp.h"
#include "main.h"


#define VDMA_BASEADDR   XPAR_AXI_VDMA_0_BASEADDR
#define VDMA_BASEADDR1  XPAR_AXI_VDMA_1_BASEADDR
#define SCALER_ID       XPAR_HLS_VIDEO_SCALER_TOP_0_DEVICE_ID//scaler id

#define VIDEO_BASEADDR0 0x11000000   

#define frame_BASEADDR0 0x03000000   
#define frame_BASEADDR1 0x04000000   

#define BUF_SIZE  960*540*3
#define BUF_SIZE1 1920*1080*3
#define BUF_SIZE2 3840*2160*3

static FATFS SD_Dev; // File System instance
char *SD_Path = "0:/";  //  string pointer to the logical drive number
static FIL fil;		/* File object write*/

u8 RD_Buf1[BUF_SIZE]  __attribute__ ((aligned(32)));
u8 RD_Buf2[BUF_SIZE1] __attribute__ ((aligned(32)));
u8 RD_Buf3[BUF_SIZE2] __attribute__ ((aligned(32)));


void Xil_DCacheFlush(void);
void scaler_config();
XHls_video_scaler_top scaler;


//from ethnet
extern int hang;
extern int lie;
extern int Flag;
extern int Flag1;


void scaler_config()
{
	int Status;
	//hls ip core inst

	Status = XHls_video_scaler_top_Initialize(&scaler, SCALER_ID);
	xil_printf("scaler init %d\r\n", Status);
	XHls_video_scaler_top_SetRows(&scaler, 540);
	XHls_video_scaler_top_SetCols(&scaler, 960);
	XHls_video_scaler_top_SetDrows(&scaler, 2160);
	XHls_video_scaler_top_SetDcols(&scaler, 3840);
	//XHls_video_scaler_top_InterruptGlobalDisable(&scaler);
	//XHls_video_scaler_top_EnableAutoRestart(&scaler);
}

void ps_wr_ddr( const unsigned char * addr, u32 size_x, u32 size_y)
{
	u32 x=0;
	u32 y=0;
	u32 r,g,b;
	for(y=size_y;y>0;y--)
	{
		for(x=0;x<size_x;x++)
		{
			b = *(addr++);
			g = *(addr++);
			r = *(addr++);
			Xil_Out32((frame_BASEADDR0+(((y-1)*size_x)+x)*4),((r<<16)|(g<<8)|(b<<0)));
		}
	}

	Xil_DCacheFlush();
}

void ps_rd_ddr(unsigned char * addr, u32 size_w, u32 size_h)
{
	u32 w=0;
	u32 h=0;
	u32 pixel_data;

	for(h=size_h;h>0;h--)
	{
		for(w=0;w<size_w;w++)
		{
			pixel_data = Xil_In32(frame_BASEADDR1+(((h-1)*size_w)+w)*4);
			*(addr++) = pixel_data;
			*(addr++) = (pixel_data>>8);
			*(addr++) = (pixel_data>>16);
		}
	}

}

void show_img( const unsigned char * addr, u32 size_x, u32 size_y,int h, int l)
{
	u32 x=0;
	u32 y=0;
	u32 r,g,b;
	addr = addr + (size_y - h)*size_x*2*3 + l*3;
	for(y=size_y;y>0;y--)
	{
		for(x=0;x<size_x;x++)
		{
			b = *(addr++);
			g = *(addr++);
			r = *(addr++);
			Xil_Out32((VIDEO_BASEADDR0+(((y-1)*size_x)+x)*4),((r<<16)|(g<<8)|(b<<0)));
			if(x==size_x-1)
			{
				addr = addr+size_x*3;
			}
		}
	}
	Xil_DCacheFlush();
}

void VDMA_init()
{
	int i;
	for(i=0;i<1920*1080;i++)
	{
		Xil_Out32(VIDEO_BASEADDR0+i*4,0);
	}
	Xil_DCacheFlush();
	Xil_Out32((VDMA_BASEADDR + 0x000), 0x3);
	Xil_Out32((VDMA_BASEADDR + 0x05c), VIDEO_BASEADDR0);
	Xil_Out32((VDMA_BASEADDR + 0x060), VIDEO_BASEADDR0);
	Xil_Out32((VDMA_BASEADDR + 0x064), VIDEO_BASEADDR0);
	Xil_Out32((VDMA_BASEADDR + 0x058), (1920*4));
	Xil_Out32((VDMA_BASEADDR + 0x054), (1920*4));
	Xil_Out32((VDMA_BASEADDR + 0x050), 1080);
}

void VDMA1_init(u32 h_stride,u32 h_active ,u32 v_active)//hang hang chang
{
	//VDMA0��DDR���� ��VIDEO_BASEADDR0��ȡ1֡ͼ������(960*540)
	Xil_Out32((VDMA_BASEADDR1 + 0x000), 0x3);              //MM2S VDMA Control Register          (offset:00h)  //8B
	Xil_Out32((VDMA_BASEADDR1 + 0x05C), frame_BASEADDR0);  //MMS2 Start Address                  (offset:5ch)
	Xil_Out32((VDMA_BASEADDR1 + 0x058), (h_stride*4));     //MM2S Frame Delay and Stride Register(offset:58h)
	Xil_Out32((VDMA_BASEADDR1 + 0x054), (h_active*4));     //MM2S Horizontal Size Register       (offset:54h)
	Xil_Out32((VDMA_BASEADDR1 + 0x050), v_active);         //MM2S Vertical Size Register         (offset:50h)

	//VDMA1дDDR����  ��VIDEO_BASEADDR1д��1֡ͼ������(3840*2160)
	Xil_Out32((VDMA_BASEADDR1 + 0x030), 0x3);              //S2MM VDMA Control Register          (offset:30h)  //108B
	Xil_Out32((VDMA_BASEADDR1 + 0x0AC), frame_BASEADDR1);  //S2MM Start Address                  (offset:ACh)
	Xil_Out32((VDMA_BASEADDR1 + 0x0A8), (h_stride*16));     //S2MM Frame Delay and Stride Register(offset:58h)
	Xil_Out32((VDMA_BASEADDR1 + 0x0A4), (h_active*16));     //S2MM Horizontal Size Register       (offset:54h)
	Xil_Out32((VDMA_BASEADDR1 + 0x0A0), v_active*4);         //S2MM Vertical Size Register         (offset:50h)
}

int SD_init()
{
	FRESULT result;
	//-----------------------mount dev-----------------------------------------------
	result = f_mount(&SD_Dev,SD_Path, 0);
	if (result != 0) {
		return XST_FAILURE;
	}
	return XST_SUCCESS;
}


int main()
{
	//int status;
	VDMA_init();
	SD_init();
	//BMP_Picture((u8 *)"17.bmp" , RD_Buf1 ,BUF_SIZE);
	//ps_wr_ddr(RD_Buf1,960,540);


	//XHls_video_scaler_top_Start(&scaler);
	//VDMA1_init(960,960,540);//hang hang chang
	//sleep(1);
	//ps_rd_ddr(RD_Buf3,3840,2160);
	//printf("store pixel done!\r\n");
	//bmp_write("0:/1717.bmp", (char *)&BMODE_3840x2160, (char *)&RD_Buf3, BUF_SIZE2, &fil);
	//printf("write bmp done!\r\n");

	struct netif *netif;

		/* the mac address of the board. this should be unique per board */
		unsigned char mac_ethernet_address[] = {
			0x00, 0x0a, 0x35, 0x00, 0x01, 0x02 };

		netif = &server_netif;

		init_platform();

		xil_printf("\r\n\r\n");
		xil_printf("----- lwIP RAW Mode TFTP server Demo Application -----\r\n");

		/* initialize lwIP */
		lwip_init();

		/* Add network interface to the netif_list, and set it as default */
		if (!xemac_add(netif, NULL, NULL, NULL, mac_ethernet_address,
					PLATFORM_EMAC_BASEADDR)) {
			xil_printf("Error adding N/W interface\r\n");
			return -1;
		}
		netif_set_default(netif);

		/* now enable interrupts */
		platform_enable_interrupts();

		/* specify that the network if is up */
		netif_set_up(netif);

		assign_default_ip(&(netif->ip_addr), &(netif->netmask), &(netif->gw));
	//#endif
		print_ip_settings(&(netif->ip_addr), &(netif->netmask), &(netif->gw));

		xil_printf("\r\n");
		print_app_header();
		/* start the application*/
		start_application();
		start_application_echo();

		xil_printf("\r\n");
	//*************************************************NET**********************************************************************//END

	while(1)
	{
		if(Flag == 1)
		{
			show_img(RD_Buf3,1920,1080,hang,lie);
			Flag = 0;
		}
		if(Flag1 == 1)
		{
			BMP_Picture((u8 *)"test.bmp" , RD_Buf1 ,BUF_SIZE);
			ps_wr_ddr(RD_Buf1,960,540);
			VDMA1_init(960,960,540);//hang hang chang
			scaler_config();
			XHls_video_scaler_top_Start(&scaler);

			//sleep(5);

			sleep(1);
			ps_rd_ddr(RD_Buf3,3840,2160);
			printf("store pixel done!\r\n");
			bmp_write("0:/test1.bmp", (char *)&BMODE_3840x2160, (char *)&RD_Buf3, BUF_SIZE2, &fil);
			printf("write bmp done!\r\n");

			Flag1 = 0;
		}
		//net
		if (TcpFastTmrFlag)
		{
			tcp_fasttmr();
			TcpFastTmrFlag = 0;
		}
		if (TcpSlowTmrFlag)
		{
			tcp_slowtmr();
			TcpSlowTmrFlag = 0;
		}
		xemacif_input(netif);
				//net
	}

    return 0;
}
