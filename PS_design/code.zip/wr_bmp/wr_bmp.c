

#include "wr_bmp.h"
#include "xil_printf.h"
#include "xil_types.h"
#include "ff.h"
#include "stdio.h"
#include "string.h"

//unsigned char Write_line_buf[1280 * 3];

void bmp_write(char *name, char *head_buf, char *data_buf, u32 len, FIL *fil)
{
	FRESULT res;
	unsigned int br;   //File R/W count
	res = f_open(fil, name, FA_CREATE_ALWAYS | FA_WRITE);
	if(res != FR_OK)
	{
		printf("error:f_open Failed!\r\n");
		return;
	}
	res = f_write(fil, head_buf, 54, &br);
	if(res != FR_OK)
	{
		f_close(fil);
		printf("error:f_write Failed!\r\n");
		return;
	}
	res = f_write(fil, data_buf, len, &br);
	f_close(fil);
	printf("BMP write successfully!\r\n");
}