#ifndef _TOP_H_
#define _TOP_H_

#include "hls_video.h"
#include "ap_int.h"

// maximum image size
#define MAX_WIDTH  4096
#define MAX_HEIGHT 2160

typedef unsigned char uchar;

// I/O Image Settings
#define INPUT_IMAGE           "0.bmp"
#define OUTPUT_IMAGE          "result_0.bmp"

// typedef video library core structures
typedef hls::stream<ap_axiu<32, 1, 1, 1> >               AXI_STREAM;
typedef hls::Mat<MAX_HEIGHT, MAX_WIDTH, HLS_8UC3>     	 RGB_IMAGE;
typedef hls::Mat<MAX_HEIGHT, MAX_WIDTH, HLS_32FC3>    	RGB_IMAGE_FLOAT;
typedef hls::Mat<MAX_HEIGHT, MAX_WIDTH, HLS_8UC1>     	GRAY_IMAGE;
typedef hls::Scalar<3, unsigned char>                 	RGB_PIXEL;
typedef hls::Scalar<3, float>                 		  	RGB_PIXEL_FLOAT;
typedef hls::Scalar<1, unsigned char>                 	GRAY_PIXEL;


//********************for sharpen********************
#define BITS_PER_PIXEL			24

typedef struct {
    uint8_t r;
    uint8_t g;
    uint8_t b;
    uint8_t a;
} Pixel;



//***************************************************



//��ͼ������
//src1:˫���β�ֵ���4kͼ
//src4:˫���β�ֵ���4k�Ҷ�ͼ
//src2:˫���β�ֵ���4k������ͼ
namespace hls
{
	void sharpen_test(RGB_IMAGE &src1, GRAY_IMAGE &src4, GRAY_IMAGE &src2,int rows, int cols);
}

Pixel* bmp_rgb_pixel_at(RGB_IMAGE &src, uint32_t x, uint32_t y);
Pixel* bmp_gray_pixel_at(GRAY_IMAGE &src, uint32_t x, uint32_t y);
int clip3(int v, int min, int max);



// top level function for HW synthesis
void image_edge_fill(RGB_IMAGE &src, RGB_IMAGE &dst, int rows, int cols);
void Bicubic_calcula(RGB_IMAGE &src, RGB_IMAGE &dst, int rows, int cols);

void hls_video_scaler_top(AXI_STREAM& input, AXI_STREAM& output, int rows, int cols,int drows, int dcols);


#endif
