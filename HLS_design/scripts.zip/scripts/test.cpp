#include "top.h"
#include "hls_opencv.h"
#include "iostream"
#include <time.h>

using namespace std;
using namespace cv;

int main(int argc,char** argv)
{
	 IplImage* src = cvLoadImage(INPUT_IMAGE);

	 CvSize s;
	 s.width = 3840;
	 s.height = 2160;
	 IplImage* dst = cvCreateImage(s,8,3);

	 AXI_STREAM src_axi, dst_axi;
	 IplImage2AXIvideo(src, src_axi);
     //image process
	 hls_video_scaler_top(src_axi, dst_axi, src->height, src->width,2160,3840);

	 AXIvideo2IplImage(dst_axi, dst);
	 cvShowImage("src_1k",src);
	 cvShowImage("hls_dst_4k",dst);
	 cvSaveImage(OUTPUT_IMAGE,dst,0);

	 waitKey(0);

	 //�ͷ��ڴ�
	 cvReleaseImage(&src);
	 cvReleaseImage(&dst);

	 return 0;

}
