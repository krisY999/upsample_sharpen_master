
template <int COLS, int ROWS,int DCOLS, int DROWS, int T>
void Resize_opr_bicubic(hls::Mat<ROWS, COLS, T>&  _src, hls::Mat<DROWS, DCOLS, T>& _dst) {
    typedef ap_fixed<32, 16, AP_RND> FT;
    typedef short N16;
    const int NTAPS = 4;
    const int NPHASES = 16;
    const int COEFF_BITS = 16; // Maximum is 16 for S16 format
    const short ES = 2; // Edge size. 2 Rows and 2 columns are needed before processing can start.
    typename filter2d_traits<HLS_TNAME(T), ap_fixed<25, 5, AP_RND>, NTAPS>::FILTER_CAST_T hcoeffs[NPHASES][NTAPS];
    typename filter2d_traits<HLS_TNAME(T), ap_fixed<25, 5, AP_RND>, NTAPS>::FILTER_CAST_T vcoeffs[NPHASES][NTAPS];
    N16 row, col;
    N16 rows, cols;
    ap_uint<32> v_phase_acc; // Vertical Phase accumulator. This accumulator is at least 16bit fractional + 13 bit integer = 29 bits wide
    ap_uint<32> h_phase_acc; // Horizontal Phase accumulator

    hls::LineBuffer<NTAPS, (COLS>DCOLS?COLS:DCOLS) + 3, hls::Scalar<HLS_MAT_CN(T), HLS_TNAME(T)> > linebuf;
    hls::Window<1, NTAPS, hls::Scalar<HLS_MAT_CN(T), HLS_TNAME(T)> > h_shreg;
    hls::Scalar<HLS_MAT_CN(T), HLS_TNAME(T)> pix_in, h_fir_out, pix_out, h_fir[NTAPS], v_fir[NTAPS];
    hls::Scalar < HLS_MAT_CN(T), HLS_TNAME(T) > temp_in[NTAPS];
    hls::Scalar < HLS_MAT_CN(T), HLS_TNAME(T) > temp_out[NTAPS];
    HLS_TNAME(T)	pix_in_ch, pix_out_ch;

    N16 rows_rw = -1, cols_rw = -1;
    bool col_rd_en;
    bool row_rd_en;
    bool col_wr_en;
    bool row_wr_en;
    ap_uint<4> v_phase;
    ap_uint<4> h_phase;
#pragma HLS array_partition variable= temp_in dim=0 complete
#pragma HLS array_partition variable= temp_out dim=0 complete
#pragma HLS array_partition variable= h_fir dim=0 complete
#pragma HLS array_partition variable= v_fir dim=0 complete
#pragma HLS array_partition variable=hcoeffs dim=2 complete
#pragma HLS array_partition variable=vcoeffs dim=2 complete

    // Initialization:
    init_scale_coefficients<NTAPS, NPHASES, COEFF_BITS>(hcoeffs[0], vcoeffs[0]); // 4 Taps, 16 phases, 16 bit signed coefficients

    N16 rows_in = _src.rows;
    N16 cols_in = _src.cols;
    N16 rows_out = _dst.rows;
    N16 cols_out = _dst.cols;
    FT row_ratio = (FT(rows_out)) / (FT)rows_in;
    FT col_ratio = (FT(cols_out)) / (FT)cols_in;

    int row_rate = (ap_fixed<4, 2, AP_RND>(0.5) + row_ratio * 65536);
    int col_rate = (ap_fixed<4, 2, AP_RND>(0.5) + col_ratio * 65536);
    rows = (rows_in > rows_out) ? rows_in : rows_out;
    cols = (cols_in > cols_out) ? cols_in : cols_out;
    assert(rows<=ROWS || rows<=DROWS);
    assert(cols<=COLS || cols<=DCOLS);
    v_phase_acc = 0;

 ROW_LOOP: for (row = 0; row < rows + 3; row++) {
    COL_LOOP: for (col = 0; col < cols + 3; col++) {
#pragma HLS PIPELINE
#pragma HLS loop_flatten off
#pragma HLS DEPENDENCE array inter false
              if (col == 0) {
                  v_phase = (v_phase_acc >> 12) & 15; // Slice out bits 15..12 from the phase accumulator (Consider rounding here!!!)
                  if (row_rate < 65536) { // Down scaling, writes are less frequent than reads
                      row_rd_en = true;
                      N16 drow = row * row_ratio;
                      if (rows_rw != drow) {
                          row_wr_en = true;
                          rows_rw = drow;
                      } else
                          row_wr_en = false;
                  } else { // Up scaling, reads are less frequent than writes
                      row_wr_en = true;
                      N16 drow = row / row_ratio;
                      if (rows_rw != drow) {
                          row_rd_en = true;
                          rows_rw = drow;
                      } else
                          row_rd_en = false;
                  }
                  if (row_rate < 65536 || row_rd_en)
                      v_phase_acc = v_phase_acc + row_rate;
              }

              h_phase = (h_phase_acc >> 12) & 15; // Slice out bits 15..12 from the phase accumulator
              if (col_rate < 65536) { // Down scaling, writes are less frequent than reads
                  col_rd_en = true;
                  N16 dcol = col * col_ratio;
                  if (col == 0 || (col > 0 && cols_rw != dcol)) {
                      col_wr_en = true;
                      cols_rw = dcol;
                  } else
                      col_wr_en = false;
              } else { // Up scaling, reads are less frequent than writes
                  col_wr_en = true;
                  N16 dcol = col / col_ratio;
                  if (col == 0 || (col > 0 && cols_rw != dcol)) {
                      col_rd_en = true;
                      cols_rw = dcol;
                  } else
                      col_rd_en = false;
              }

              if (col > 0 && (col_rate < 65536 || col_rd_en))
                  h_phase_acc = h_phase_acc + col_rate;
              else
                  h_phase_acc = col_rate;

              if (col_rd_en) {
                  h_shreg.shift_left();
                  if (row_rd_en) {
                      if (row < rows && col < cols) {
                          pix_in = _src.read();
                          h_shreg.insert(pix_in, 0, NTAPS - 1);
                      } else if (col >= cols && row < rows) {
                          h_shreg.insert(pix_in, 0, NTAPS - 1);
                      } else if (row >= rows) {
                          for (int m = 0; m < HLS_MAT_CN(T); m++)
                              pix_in.val[0] = 0;
                          h_shreg.insert(pix_in, 0, NTAPS - 1);
                      }
                  }
              }

              for (int i = 0; i < NTAPS; i++) {
                  temp_in[i] = linebuf.val[i][col];
              }

              if (col_wr_en) {
                  if ((row_rd_en) || (row < ES) || (row >= rows - ES)) {
                      for (int i = NTAPS - 1; i > 0; i--) {
                          temp_out[i] = temp_in[i - 1];
                      }
H_LOOP: for (int i = 0; i < NTAPS; i++) {
            h_fir[i] =
                (col > i) ?
                h_shreg.getval(0, i) :
                h_shreg.getval(0, NTAPS - 1 - col);
        }
        h_fir_out = scale_operator<NTAPS, COEFF_BITS, T>(h_fir,
                hcoeffs[h_phase]);
        temp_out[0] = h_fir_out;
        v_fir[NTAPS - 1] = h_fir_out;
                  } else {
                      for (int i = NTAPS - 1; i >= 0; i--) {
                          temp_out[i] = temp_in[i];
                      }
                      v_fir[NTAPS - 1] = temp_in[0];
                  }
V_LOOP: for (int i = 0; i < NTAPS - 1; i++) {
            v_fir[i] =
                (row > 0) ? temp_out[NTAPS - 1 - i] : temp_out[0];
        }
              }

              for (int i = 0; i < NTAPS; i++) {
                  linebuf.val[i][col] = (row > 0) ? temp_out[i] : temp_out[0];
              }

              if (row >= 3 && col >= 3 && row_wr_en && col_wr_en) {
                  pix_out = scale_operator<NTAPS, COEFF_BITS, T>(v_fir, vcoeffs[v_phase]);
                  _dst.write(pix_out);
              }
          }
          }
}
